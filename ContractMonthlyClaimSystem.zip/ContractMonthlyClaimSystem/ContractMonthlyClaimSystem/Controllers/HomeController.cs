using ContractMonthlyClaimSystem.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using ContractMonthlyClaimSystem.Data;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using System.IO;
using System.Linq;

namespace ContractMonthlyClaimSystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<HomeController> _logger;

        public HomeController(ApplicationDbContext context, ILogger<HomeController> logger)
        {
            _context = context;
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Lecturer()
        {
            var model = new LecturerViewModel
            {
                Claims = _context.Claims.Where(c => c.LecturerId == User.Identity.Name).ToList() // Get claims for the logged-in lecturer
            };
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> SubmitClaim(Claim claim, IFormFile supportingDocs)
        {
            if (ModelState.IsValid)
            {
                claim.LecturerId = User.Identity.Name;
                claim.SubmissionDate = DateTime.Now;
                claim.Status = "Pending";

                if (supportingDocs != null)
                {
                    // Define the uploads directory path
                    var uploadsDirectory = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads");

                    // Check if the directory exists, if not, create it
                    if (!Directory.Exists(uploadsDirectory))
                    {
                        Directory.CreateDirectory(uploadsDirectory);
                    }

                    // Combine the file path with the file name
                    var filePath = Path.Combine(uploadsDirectory, supportingDocs.FileName);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await supportingDocs.CopyToAsync(stream);
                    }

                    // Store the file name in the claim object
                    claim.SupportingDocuments = supportingDocs.FileName;
                }

                // Add the claim to the database context and save changes
                _context.Claims.Add(claim);
                await _context.SaveChangesAsync();

                // Redirect back to the Lecturer dashboard
                return RedirectToAction("Lecturer");
            }

            // If model state is invalid, return the claim to the view
            return View(claim);
        }

        [HttpGet]
        public IActionResult Coordinator()
        {
            var claims = _context.Claims.Where(c => c.Status == "Pending").ToList();
            return View(claims);
        }

        [HttpPost]
        public async Task<IActionResult> ApproveClaim(int id)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim != null)
            {
                claim.Status = "Approved";
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("Coordinator");
        }

        [HttpPost]
        public async Task<IActionResult> RejectClaim(int id)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim != null)
            {
                claim.Status = "Rejected";
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("Coordinator");
        }

        public IActionResult Manager()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}