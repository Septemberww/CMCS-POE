﻿using System.Collections.Generic;

namespace ContractMonthlyClaimSystem.Models
{
    public class LecturerViewModel
    {
        public List<Claim> Claims { get; set; } = new List<Claim>(); 
    }
}
