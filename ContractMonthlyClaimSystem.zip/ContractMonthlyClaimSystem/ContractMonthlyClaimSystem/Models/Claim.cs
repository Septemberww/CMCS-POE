﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ContractMonthlyClaimSystem.Models
{
    public class Claim
    {
        public int Id { get; set; }
        public string? Description { get; set; }
        public string? LecturerId { get; set; }

        [Required]
        public decimal HoursWorked { get; set; }

        [Required]
        public decimal HourlyRate { get; set; }

        public string? SupportingDocuments { get; set; }

        public string? Status { get; set; } // Pending, Approved, Rejected

        public DateTime SubmissionDate { get; set; }

        public DateTime ClaimMonth { get; set; }
    }
}
